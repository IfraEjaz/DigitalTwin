using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Geometry;

public class Turtlebot3Controller: MonoBehaviour
{
    private ROSConnection ros;
    public string topicName = "/cmd_vel";
    public Transform robotBase; // Assign the robot base (like TurtleBot3 root) in Inspector
    public float maxLinearVelocity = 0.2f; // Maximum linear velocity (m/s)
    public float maxAngularVelocity = 1.0f; // Maximum angular velocity (rad/s)
    public float accelerationRate = 0.5f; // Acceleration rate (m/s^2)
    public float rotationAccelerationRate = 2.0f; // Angular acceleration (rad/s^2)

    private float linearVelocity = 0f;
    private float angularVelocity = 0f;
    private float currentLinearVelocity = 0f; // To store the current velocity for acceleration control
    private float currentAngularVelocity = 0f; // To store the current angular velocity for acceleration control

    private float leftWheelVelocity = 0f;
    private float rightWheelVelocity = 0f;

    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.Subscribe<TwistMsg>(topicName, CmdVelCallback);
        Debug.Log("Subscribed to /cmd_vel");
    }

    void CmdVelCallback(TwistMsg msg)
    {
        linearVelocity = (float)msg.linear.x;
        angularVelocity = (float)msg.angular.z;
        Debug.Log($"[Unity] Received: linear = {linearVelocity}, angular = {angularVelocity}");
    }

    void Update()
    {
        // Smooth acceleration for linear velocity
        currentLinearVelocity = Mathf.MoveTowards(currentLinearVelocity, linearVelocity, accelerationRate * Time.deltaTime);
        // Smooth acceleration for angular velocity
        currentAngularVelocity = Mathf.MoveTowards(currentAngularVelocity, angularVelocity, rotationAccelerationRate * Time.deltaTime);

        // Calculate wheel velocities based on linear and angular velocities
        float wheelBaseWidth = 0.1f; // Distance between left and right wheels (in meters)
        float wheelRadius = 0.033f; // Radius of the wheels (in meters)

        leftWheelVelocity = (currentLinearVelocity - (wheelBaseWidth / 2) * currentAngularVelocity) / wheelRadius;
        rightWheelVelocity = (currentLinearVelocity + (wheelBaseWidth / 2) * currentAngularVelocity) / wheelRadius;

        // Limit the velocities to the max values to avoid unrealistic motion
        leftWheelVelocity = Mathf.Clamp(leftWheelVelocity, -maxLinearVelocity / wheelRadius, maxLinearVelocity / wheelRadius);
        rightWheelVelocity = Mathf.Clamp(rightWheelVelocity, -maxLinearVelocity / wheelRadius, maxLinearVelocity / wheelRadius);

        // Move the robot based on the calculated wheel velocities
        MoveRobot();
    }

    void MoveRobot()
    {
        // Move the robot's base forward and rotate it using the current velocities
        float moveStep = currentLinearVelocity * Time.deltaTime;
        float turnStep = currentAngularVelocity * Time.deltaTime * Mathf.Rad2Deg;

        robotBase.Translate(Vector3.forward * moveStep);
        robotBase.Rotate(Vector3.up * turnStep);

        // Optionally, you can visualize the wheel velocities or adjust wheel animations here.
        Debug.Log($"Left Wheel Velocity: {leftWheelVelocity}, Right Wheel Velocity: {rightWheelVelocity}");
    }
}

