using UnityEngine;

public class CameraFollow : MonoBehaviour
{
    public Transform target; // Reference to the TurtleBot
    public Vector3 offset; // Offset to adjust camera position relative to the TurtleBot
    public float smoothSpeed = 0.125f; // Smooth transition speed

    void FixedUpdate()
    {
        // Calculate the desired position
        Vector3 desiredPosition = target.position + offset;

        // Smoothly move the camera to the desired position
        Vector3 smoothedPosition = Vector3.Lerp(transform.position, desiredPosition, smoothSpeed);
        transform.position = smoothedPosition;

        // Always keep the camera looking at the target
        transform.LookAt(target);
    }
}

