using UnityEngine;
using Unity.Robotics.ROSTCPConnector;
using RosMessageTypes.Geometry;

public class WheelBasedTurtleBot : MonoBehaviour
{
    public Transform leftWheel;
    public Transform rightWheel;

    public float wheelRadius = 0.033f;
    public float wheelBase = 0.16f;

    private float leftWheelVelocity = 0f;
    private float rightWheelVelocity = 0f;

    private Rigidbody rb;

    ROSConnection ros;
    public string topicName = "/cmd_vel";

    void Start()
    {
        ros = ROSConnection.GetOrCreateInstance();
        ros.Subscribe<TwistMsg>(topicName, CmdVelCallback);

        rb = GetComponent<Rigidbody>();
        if (rb == null)
        {
            rb = gameObject.AddComponent<Rigidbody>();
            rb.mass = 2f;
            rb.linearDamping = 0.2f;
            rb.angularDamping = 0.1f;
            rb.useGravity = false; // Turn off gravity if your bot is flat on a plane
        }
    }

    void CmdVelCallback(TwistMsg msg)
    {
        float linear = (float)msg.linear.x;
        float angular = (float)msg.angular.z;

        leftWheelVelocity = (linear - angular * wheelBase / 2f) / wheelRadius;
        rightWheelVelocity = (linear + angular * wheelBase / 2f) / wheelRadius;
    }

    void FixedUpdate()
    {
        float dt = Time.fixedDeltaTime;

        // ✅ Rotate the wheels visually
        leftWheel.Rotate(Vector3.right, leftWheelVelocity * Mathf.Rad2Deg * dt);
        rightWheel.Rotate(Vector3.right, rightWheelVelocity * Mathf.Rad2Deg * dt);

        // ✅ Move robot base using wheel velocity
        float linearVelocity = wheelRadius * (rightWheelVelocity + leftWheelVelocity) / 2f;
        float angularVelocity = wheelRadius * (rightWheelVelocity - leftWheelVelocity) / wheelBase;

        Vector3 move = transform.forward * linearVelocity * dt;
        Quaternion turn = Quaternion.Euler(0, angularVelocity * Mathf.Rad2Deg * dt, 0);

        rb.MovePosition(rb.position + move);
        rb.MoveRotation(rb.rotation * turn);
    }
}

